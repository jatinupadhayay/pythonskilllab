> **TABLE** **OF** **CONTENTS**

||
||
||
||
||
||
||
||
||
||
||

> **Automatic** **Exam** **Time** **Table** **Generation** **:-**

**Objective:-**

The objective of our automatic timetable generation is to create a
system that automatically schedules exams without conflicts, ensuring no
overlapping exams, checking faculty availability, and considering room
capacity limits. The system aims to make the scheduling process easier
and more efficient by handling constraints like date and time conflicts
and providing a user-friendly interface for managing and generating the
final exam timetable.

**Functional** **Requirements:-**

Upload Data Files: The user must be able to upload Excel files
containing data about subjects, rooms, and faculty. These files will be
processed to generate the timetable.

Manual Subject Selection: The user can manually select subjects for
which they want to schedule exams.

Faculty and Room Assignment: The application assigns available faculty
and rooms to the exams while avoiding conflicts like overlapping exams
or double-booked faculty and rooms.

Conflict Checking: The system checks for any date and time conflicts
when scheduling exams, ensuring that no two exams overlap for the same
faculty or in the same room.

Timetable Generation: The system generates a complete timetable based on
the input data and assigned constraints, such as room capacity and
faculty availability.

Timetable Editing: Users can manually edit the generated timetable to
make changes if needed, such as adjusting exam dates, times, or room
assignments.

Export Timetable: The final timetable can be exported to Excel or Word
for easy sharing and printing.

Faculty Availability Check: The application checks the availability of
faculty members before assigning them to an exam. If a faculty member is
already assigned at a certain date and time, it suggests alternative
slots.

PDF/Excel Export: The generated timetable can be saved and exported in a
user-friendly format, like PDF or Excel.

User-Friendly Interface: The system provides an easy-to-use interface,
allowing users to view, add, delete, and modify data related to
subjects, faculty, and rooms. Scrollbars and menus make navigation
simple.

> **Frameworks** **and** **Libraries**

**Tkinter**: For creating the graphical user interface (GUI).

**Pandas**: For managing and manipulating data from Excel files.

**Openpyxl**: For reading and writing Excel files.

**Docx** (python-docx): To export generated timetables into Word format.

**Inputs:-**

Input Data:

**Subjects** **Excel**: Lists of subjects for each academic year and
department.

**Faculty** **Excel**: Names, available time slots, and other relevant
information.

**Rooms** **Excel**: Room names/numbers with associated capacity.
**Outputs**

> • **Extracted** **Text:**
>
> o The text extracted from the PDF between the specified heading and
> the next heading.
>
> • **Extracted** **Tables:**
>
> o Tables extracted from the PDF following the specified heading, saved
> as an Excel file and returned to the user.
>
> **User** **Interface** **Requirements** 1**:** **Main** **Menu:**
>
> Buttons to navigate (Load Data, Generate Timetable, View Timetable,
> Exit). **Data** **Loading:**
>
> Abutton to upload Excel files.
>
> **Data** **Display**:
>
> Tables to show and edit subjects, rooms, and faculty. **Timetable**
> **Generation**:
>
> Options to select subjects and enter exam dates and times. **Faculty**
> **and** **RoomAssignment:**
>
> Drop-down menus to choose faculty and rooms. **Timetable**
> **Preview:**
>
> Asection to show the timetable before saving. **Export** **Options:**
>
> Abutton to save the timetable (e.g., as aWord document).
> **Navigation:**
>
> Scrollbars and a menu for easy movement through the application.
>
> <img src="./io1zwoed.png"
> style="width:2.27083in;height:1.77083in" /><img src="./n0ysxwtq.png" style="width:6in;height:2.76042in" />**Input**
> **Image:-**
>
> <img src="./u0cjjwvr.png" style="width:6in;height:1.82292in" />**Output**

<img src="./pmqxwube.png" style="width:6in;height:5.52083in" />

> **Conclusion**
>
> The timetable generator project successfully streamlines the process
> of creating and managing exam schedules. By allowing users to easily
> upload data, select subjects, and assign faculty and rooms, the
> application minimizes scheduling conflicts and enhances efficiency.
> Its user-friendly interface and export options ensure that users can
> quickly generate and share timetables in various formats. Overall, the
> project meets the needs of educational institutions by providing an
> effective solution for organizing exam schedules while considering
> faculty availability and room capacities.
>
> **References**
>
> <img src="./lpclei14.png"
> style="width:0.125in;height:0.15625in" />Python Tinker tutorial
> [*-<u>https://www.youtube.com/watch?v=-</u>*](https://www.youtube.com/watch?v=-Q4lm8eYulw&list=PLu0W_9lII9ajLcqRcj4PoEihkukF_OTzA)
>
> [*<u>Q4lm8eYulw&list=PLu0W_9lII9ajLcqRcj4PoEihkukF_OTzA</u>*](https://www.youtube.com/watch?v=-Q4lm8eYulw&list=PLu0W_9lII9ajLcqRcj4PoEihkukF_OTzA)
>
> *python* *pandas*
> *tutorial-[<u>https://www.youtube.com/results?search_query=python+pandas+tutorial</u>](https://www.youtube.com/results?search_query=python+pandas+tutorial)*
